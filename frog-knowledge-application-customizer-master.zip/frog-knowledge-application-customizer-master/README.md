# frog-knowledge-application-customizer

A SharePoint Framework client-side extension developed for the frog Knowledge site to provide application customization features.

About the SharePoint Framework: https://docs.microsoft.com/en-us/sharepoint/dev/spfx/sharepoint-framework-overview

### Tech Stack
* React
* Microsoft SPFx
* Microsoft Fluent UI (React Controls)
* SharePoint PnP SPFx (React Controls)
* SharePoint JSOM
* TypeScript (3.7+)
* Node (v10.x)
* Gulp
* Webpack
* Visual Studio Code

### Code Structure

* There are no configurable component props for this extension as all configuration values are stored inline with this dedicated component for the frog Knowledge site. It is not intended to ever be used in the context of another SharePoint site within the frog organization.

### Install

* Dependencies:
  * Node v14.17 (recommend using nvm - Node Version Manager)
  * Gulp ( `npm install -g gulp` )
  * Yarn ( `npm install -g yarn` )

```bash
git clone https://github.com/frog/frog-knowledge-application-customizer
yarn install
```

### Build Options
* gulp serve (for development/testing)
* gulp clean
* gulp bundle --ship (building and bundling the extension for deployment)
* gulp package-solution --ship (packaging the extension for deployment)

### Deployment
* sharepoint/solution/frog-knowledge-application-customizer.sppkg gets uploaded to frog SharePoint App Catalog (replace existing and deploy): https://frogdesign.sharepoint.com/sites/apps/AppCatalog

