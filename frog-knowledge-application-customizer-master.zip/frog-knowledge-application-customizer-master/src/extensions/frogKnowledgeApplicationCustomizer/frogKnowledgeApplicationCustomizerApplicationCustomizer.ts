import * as React from 'react';
import * as ReactDom from 'react-dom';
import {
  BaseApplicationCustomizer,
  PlaceholderContent,
  PlaceholderName
} from '@microsoft/sp-application-base';
import { override } from '@microsoft/decorators';
import { sp } from "@pnp/sp";
import "@pnp/sp/webs";
import "@pnp/sp/site-groups/web";
import './frogKnowledgeApplicationCustomizerApplicationCustomizer.module.scss';
import frogKnowledgeSiteNavHeader from './components/frogKnowledgeSiteNavHeader';
import { IfrogKnowledgeSiteNavHeaderProps } from './components/IfrogKnowledgeSiteNavHeaderProps';
import { Configuration } from "./config";
import { SitePage } from "./enums";

export interface IfrogKnowledgeApplicationCustomizerApplicationCustomizerProperties {}

export default class frogKnowledgeApplicationCustomizerApplicationCustomizer
  extends BaseApplicationCustomizer<IfrogKnowledgeApplicationCustomizerApplicationCustomizerProperties> {

  @override
  public async onInit(): Promise<void> {
    try {
      if (this.context.pageContext.site.serverRelativeUrl !== Configuration.SiteRoot) {
        throw(new Error("The frog Knowledge Uploader webpart cannot be used in this SharePoint site context."));
      }

      sp.setup({ spfxContext: this.context });

      this.context.placeholderProvider.changedEvent.add(this, this.renderPlaceHolders);
      this.updateReferencePDFLinksInSearchResults();
      this.openDetailsPaneInPreviewMode();

      this.setPageTypeAttributes();
      this.context.application.navigatedEvent.add(this, () => {
        this.setPageTypeAttributes();
      });

      this.setPageUserAttributes();

      console.log(`Initialized frogKnowledgeApplicationCustomizer (${ Configuration.CurrentVersion })`);
    } catch (error) {
      console.log(error);
    }
  }

  @override
  public onDispose(): void {}

  private setPageTypeAttributes(): void {
    document.body.classList.toggle("isSitePage", this.context.pageContext?.listItem?.id > 0 || window.location.href.includes("/news.aspx"));
    document.body.classList.toggle("isSiteHomePage", this.context.pageContext?.listItem?.id === SitePage.Home);
  }

  private async setPageUserAttributes(): Promise<void> {
    const knowledgeManagersSiteGroupInfo = await sp.web.siteGroups.getByName("Knowledge Managers").expand("CanCurrentUserViewMembership")();
    const knowledgeOwnersSiteGroupInfo = await sp.web.siteGroups.getByName("Knowledge Owners").expand("CanCurrentUserViewMembership")();
    const isKnowledgeManager = knowledgeManagersSiteGroupInfo["CanCurrentUserViewMembership"];
    const isKnowledgeOwner = knowledgeOwnersSiteGroupInfo["CanCurrentUserViewMembership"];
    document.body.classList.toggle("isStandardUser", !isKnowledgeManager && !isKnowledgeOwner);
  }

  private renderPlaceHolders(): void {
    try {
      if (!document.querySelector("#topPlaceholderContent")) {
        const topPlaceholder: PlaceholderContent = this.context.placeholderProvider.tryCreateContent(PlaceholderName.Top);
        if (topPlaceholder?.domElement) {
          topPlaceholder.domElement.id = "topPlaceholderContent";
          const element: React.ReactElement<IfrogKnowledgeSiteNavHeaderProps> = React.createElement(
            frogKnowledgeSiteNavHeader,
            { context: this.context }
          );
          ReactDom.render(element, topPlaceholder.domElement);
          document.querySelector("#spSiteHeader")?.after(topPlaceholder.domElement);
          document.querySelector(".od-TopBar-header")?.after(topPlaceholder.domElement);
          if (document.querySelector("#spPageChromeAppDiv")) {
            const observer = new MutationObserver((mutations, o) => {
              mutations.forEach((mutation: MutationRecord) => {
                mutation.addedNodes.forEach((node: HTMLElement) => {
                  if (node.nodeType === Node.ELEMENT_NODE) {
                    if (node.id === "spSiteHeader") {
                      node.after(topPlaceholder.domElement);
                    }
                  }
                });
              });
            });
            observer.observe(document.querySelector("#spPageChromeAppDiv"), { childList: true, subtree: true });
          }
        }
      }
    } catch (error) {
      console.log(error);
    }
  }

  private updateReferencePDFLinksInSearchResults(): void {
    try {
      if (document.querySelector("#SuiteNavWrapper")) {
        const observer = new MutationObserver((mutations, o) => {
          mutations.forEach((mutation: MutationRecord) => {
            mutation.addedNodes.forEach((node: HTMLElement) => {
              if (node.nodeType === Node.ELEMENT_NODE) {
                node.querySelectorAll(`:scope a[href$=".pdf"]`).forEach((a: HTMLAnchorElement) => {
                  a.href += "?web=1";
                });
              }
            });
          });
        });
        observer.observe(document.querySelector("#SuiteNavWrapper"), { childList: true, subtree: true });
      }
    } catch (error) {
      console.log(error);
    }
  }

  private openDetailsPaneInPreviewMode(): void {
    let isShowPropertiesButtonClicked: boolean = false;
    try {
      const observer = new MutationObserver((mutations, o) => {
        const view = document.querySelector(".OneUp");
        if (view) {
          if (!isShowPropertiesButtonClicked) {
            if (view.classList.contains("OneUp--hasInfoPane")) {
              isShowPropertiesButtonClicked = true;
            } else {
              const button: HTMLButtonElement = document.querySelector(`button[data-automationid="showProperties"]`);
              if (button) {
                button.click();
                isShowPropertiesButtonClicked = true;
              }
            }
          }
        } else {
          isShowPropertiesButtonClicked = false;
        }
      });
      observer.observe(document.body, { childList: true, subtree: true });
    } catch (error) {
      console.log(error);
    }
  }
}
