import {
  INavLink,
  INavLinkGroup
} from "office-ui-fabric-react";

const Configuration = {
  CurrentVersion: "1.0.1.9",
  BaseUrl: "https://frogdesign.sharepoint.com",
  SiteRoot: "/sites/Knowledge",
  NavLinks: {
    Home: <INavLink>{ url: "/sites/Knowledge/SitePages/Home.aspx", name: "Home" },
    CaseStudies: <INavLink>{ url: "/sites/Knowledge/Case Studies/Forms/AllItems.aspx", name: "Case Studies" },
    PitchesAndProposals: <INavLink>{ url: "/sites/Knowledge/Pitches  Proposals/Forms/AllItems.aspx", name: "Pitches & Proposals" },
    POVsAndCapabilities: <INavLink>{ url: "/sites/Knowledge/POVs  Capabilities/Forms/AllItems.aspx", name: "POVs & Capabilities" },
    EncyclopediasAndReferenceDecks: <INavLink>{ url: "/sites/Knowledge/Encyclopedias  Reference Decks/Forms/AllItems.aspx", name: "Encyclopedias & Reference Decks" },
    TemplatesAndToolkits: <INavLink>{ url: "/sites/Knowledge/Templates  Toolkits/Forms/AllItems.aspx", name: "Templates & Toolkits" },
    Deliverables: <INavLink>{ url: "/sites/Knowledge/Deliverables/Forms/AllItems.aspx", name: "Deliverables" },
    Presentations: <INavLink>{ url: "/sites/Knowledge/Presentations/Forms/AllItems.aspx", name: "Presentations" },
    PursuitResources: <INavLink>{ url: "/sites/Knowledge/SitePages/Pursuit-Resources.aspx", name: "Pursuit Resources" },
    RestrictedAssets: <INavLink>{ url: "/sites/Knowledge/Lists/Restricted%20Assets/AllItems.aspx", name: "Restricted Assets" },
    VideoChannel: <INavLink>{ url: "https://web.microsoftstream.com/channel/5790a361-be6c-4abf-ac36-a6d0c02d84a3", name: "Video Channel", target: "_blank" },
    Contribute: <INavLink>{ url: "/sites/Knowledge/SitePages/Contribute.aspx", name: "Contribute" },
    HelpAndFeedback: <INavLink>{ url: "/sites/Knowledge/SitePages/Help-%26-Feedback.aspx", name: "Help & Feedback" }
  },
  NavLinkGroups: <INavLinkGroup[]>[]
};

Configuration.NavLinkGroups = [
  { links: [ Configuration.NavLinks.Home ] },
  { links: [
    Configuration.NavLinks.CaseStudies,
    Configuration.NavLinks.PitchesAndProposals,
    Configuration.NavLinks.POVsAndCapabilities,
    Configuration.NavLinks.EncyclopediasAndReferenceDecks,
    Configuration.NavLinks.TemplatesAndToolkits,
    Configuration.NavLinks.Deliverables,
    Configuration.NavLinks.Presentations
  ]},
  { links: [
    Configuration.NavLinks.PursuitResources,
    Configuration.NavLinks.VideoChannel,
    Configuration.NavLinks.RestrictedAssets
  ]},
  { links: [ Configuration.NavLinks.Contribute ] },
  { links: [ Configuration.NavLinks.HelpAndFeedback ] }
];

export { Configuration };
