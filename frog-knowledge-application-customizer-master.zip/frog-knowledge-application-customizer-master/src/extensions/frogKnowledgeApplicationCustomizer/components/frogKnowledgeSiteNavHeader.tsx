import * as React from "react";
import {
  IconButton,
  ActionButton,
  Panel,
  PanelType,
  Nav
} from "office-ui-fabric-react";
import { IfrogKnowledgeSiteNavHeaderProps } from "./IfrogKnowledgeSiteNavHeaderProps";
import styles from "./frogKnowledgeSiteNavHeader.module.scss";
import { Configuration } from "../config";

interface IfrogKnowledgeSiteNavHeaderState {
  isNavPanelOpen: boolean;
}

export default class frogKnowledgeUploader extends React.Component<IfrogKnowledgeSiteNavHeaderProps, IfrogKnowledgeSiteNavHeaderState, {}> {

  public constructor(props: IfrogKnowledgeSiteNavHeaderProps) {
    super(props);

    this.state = {
      isNavPanelOpen: false
    };
  }

  public async componentDidMount(): Promise<void> {
    await this.load();
  }

  private async load(): Promise<void> {}

  public render(): React.ReactElement<IfrogKnowledgeSiteNavHeaderProps> {
    const {
      isNavPanelOpen
    } = this.state;

    return (
      <div>
        <div className={ styles.frogKnowledgeSiteNavHeader }>
          <IconButton
            iconProps={{ iconName: "GlobalNavButton" }}
            onClick={ () => { this.setState({ isNavPanelOpen: true }); } }
            title="Open Site Navigation" />
          <div className={ styles.categoriesGroup }>
            <ActionButton
              href={ Configuration.NavLinks.Home.url }
              title={ Configuration.NavLinks.Home.name }>
              { Configuration.NavLinks.Home.name }
            </ActionButton>
            <ActionButton
              href={ Configuration.NavLinks.CaseStudies.url }
              title={ Configuration.NavLinks.CaseStudies.name }>
              { Configuration.NavLinks.CaseStudies.name }
            </ActionButton>
            <ActionButton
              href={ Configuration.NavLinks.PitchesAndProposals.url }
              title={ Configuration.NavLinks.PitchesAndProposals.name }>
              { Configuration.NavLinks.PitchesAndProposals.name }
            </ActionButton>
            <ActionButton
              href={ Configuration.NavLinks.TemplatesAndToolkits.url }
              title={ Configuration.NavLinks.TemplatesAndToolkits.name }>
              { Configuration.NavLinks.TemplatesAndToolkits.name }
            </ActionButton>
            <ActionButton
              href={ Configuration.NavLinks.PursuitResources.url }
              title={ Configuration.NavLinks.PursuitResources.name }>
              { Configuration.NavLinks.PursuitResources.name }
            </ActionButton>
          </div>
          <ActionButton
            href={ Configuration.NavLinks.Contribute.url }
            title={ Configuration.NavLinks.Contribute.name }
            iconProps={{ iconName: "Add" }}
            className={ styles.contributeButton }>
            { Configuration.NavLinks.Contribute.name }
          </ActionButton>
          <ActionButton
            href={ Configuration.NavLinks.HelpAndFeedback.url }
            title={ Configuration.NavLinks.HelpAndFeedback.name }
            iconProps={{ iconName: "Info" }}>
            { Configuration.NavLinks.HelpAndFeedback.name }
          </ActionButton>
        </div>
        <Panel
          className={ styles.frogKnowledgeSiteNavPanel }
          isOpen={ isNavPanelOpen }
          isLightDismiss
          onDismiss={ () => { this.setState({ isNavPanelOpen: false }); } }
          type={ PanelType.customNear }
          headerText="Knowledge"
          customWidth={ "280px" }
          title="Close">
            <Nav
              groups={ Configuration.NavLinkGroups }
              onLinkClick={ () => { this.setState({ isNavPanelOpen: false }); } }
            />
        </Panel>
      </div>
    );
  }
}
