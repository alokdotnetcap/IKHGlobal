export interface IfrogKnowledgeSiteNavHeaderProps {
  context: any;
}
