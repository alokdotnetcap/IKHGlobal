define([], function() {
  return {
    "Title": "frogKnowledgeApplicationCustomizerApplicationCustomizer"
  }
});
