declare interface IfrogKnowledgeApplicationCustomizerApplicationCustomizerStrings {
  Title: string;
}

declare module 'frogKnowledgeApplicationCustomizerApplicationCustomizerStrings' {
  const strings: IfrogKnowledgeApplicationCustomizerApplicationCustomizerStrings;
  export = strings;
}
