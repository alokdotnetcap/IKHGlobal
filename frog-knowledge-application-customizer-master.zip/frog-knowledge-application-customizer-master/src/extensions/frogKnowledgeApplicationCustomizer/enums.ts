export enum SitePage {
  Home = 1,
  Contribute = 6,
  HelpAndFeedback = 15
}
